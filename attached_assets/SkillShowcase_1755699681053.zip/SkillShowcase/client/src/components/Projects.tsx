import { ExternalLink, Github } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

export default function Projects() {
  const titleRef = useScrollAnimation();
  const project1Ref = useScrollAnimation();
  const project2Ref = useScrollAnimation();
  const project3Ref = useScrollAnimation();
  const project4Ref = useScrollAnimation();
  const viewMoreRef = useScrollAnimation();

  const projects = [
    {
      title: "Image Watermarking System",
      description: "A web application using Machine Learning to detect, add, or remove watermarks from images for content protection. Built with advanced digital image processing techniques.",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      tech: ["Python", "Machine Learning", "Image Processing"],
      ref: project1Ref
    },
    {
      title: "AI Chatbot",
      description: "An intelligent chatbot capable of understanding and responding to queries for customer support simulation. Implements natural language processing techniques.",
      image: "https://images.unsplash.com/photo-1531746790731-6c087fecd65a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      tech: ["Python", "NLP", "AI"],
      ref: project2Ref
    },
    {
      title: "File Compression Utility",
      description: "Implemented Huffman Coding algorithm to reduce file sizes and optimize storage usage. Demonstrates strong understanding of data structures and algorithms.",
      image: "https://images.unsplash.com/photo-1518432031352-d6fc5c10da5a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      tech: ["C++", "Algorithms", "Data Structures"],
      ref: project3Ref
    },
    {
      title: "Language Translator Web App",
      description: "A multilingual translation application supporting multiple languages. Built with Streamlit and integrated with Google Translate API for real-time translations.",
      image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      tech: ["Python", "Streamlit", "Google Translate API"],
      ref: project4Ref
    }
  ];

  return (
    <section id="projects" className="py-20 bg-slate-50 dark:bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={titleRef} className="text-center mb-16 animate-on-scroll">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">Featured Projects</h2>
          <div className="w-24 h-1 bg-primary-600 mx-auto rounded-full"></div>
          <p className="text-lg text-slate-600 dark:text-slate-300 mt-4 max-w-2xl mx-auto">
            Here are some of my recent projects that demonstrate my skills in web development, AI, and software engineering.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div key={index} ref={project.ref} className="project-card bg-white dark:bg-slate-800 rounded-xl shadow-lg overflow-hidden transition-all duration-300 animate-on-scroll">
              <img 
                src={project.image} 
                alt={`${project.title} interface`} 
                className="w-full h-48 object-cover" 
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-3" data-testid={`text-project-title-${index + 1}`}>
                  {project.title}
                </h3>
                <p className="text-slate-600 dark:text-slate-300 mb-4">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tech.map((tech, techIndex) => (
                    <span 
                      key={techIndex}
                      className="px-3 py-1 bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-200 text-sm rounded-full"
                      data-testid={`text-tech-${tech.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                <div className="flex space-x-4">
                  <button className="text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium inline-flex items-center" data-testid={`button-demo-${index + 1}`}>
                    <ExternalLink className="mr-1 h-4 w-4" /> Live Demo
                  </button>
                  <button className="text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium inline-flex items-center" data-testid={`button-code-${index + 1}`}>
                    <Github className="mr-1 h-4 w-4" /> Code
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div ref={viewMoreRef} className="text-center mt-12 animate-on-scroll">
          <a 
            href="https://github.com/ibtesamiqbal" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center bg-primary-600 hover:bg-primary-700 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105"
            data-testid="button-view-more-projects"
          >
            <Github className="mr-2 h-4 w-4" />
            View More Projects
          </a>
        </div>
      </div>
    </section>
  );
}
