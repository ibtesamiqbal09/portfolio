import { useScrollAnimation, useSkillBarAnimation } from '../hooks/useScrollAnimation';
import { SiPython, SiJavascript, SiReact, SiDocker, SiAmazon, SiGit } from 'react-icons/si';

export default function Skills() {
  const titleRef = useScrollAnimation();
  const programmingRef = useSkillBarAnimation();
  const frameworksRef = useSkillBarAnimation();
  const techIconsRef = useScrollAnimation();

  const programmingSkills = [
    { name: 'Python', level: 90 },
    { name: 'JavaScript', level: 85 },
    { name: 'C++', level: 80 },
    { name: 'HTML/CSS', level: 90 },
  ];

  const frameworkSkills = [
    { name: 'Django/Flask', level: 85 },
    { name: 'TensorFlow', level: 75 },
    { name: 'Docker/AWS', level: 70 },
    { name: 'Git/GitHub', level: 90 },
  ];

  return (
    <section id="skills" className="py-20 bg-white dark:bg-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={titleRef} className="text-center mb-16 animate-on-scroll">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">Skills & Technologies</h2>
          <div className="w-24 h-1 bg-primary-600 mx-auto rounded-full"></div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Programming Languages */}
          <div ref={programmingRef} className="animate-on-scroll">
            <h3 className="text-2xl font-semibold text-slate-900 dark:text-white mb-8">Programming Languages</h3>
            <div className="space-y-6">
              {programmingSkills.map((skill, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-2">
                    <span className="text-slate-700 dark:text-slate-300 font-medium" data-testid={`text-skill-${skill.name.toLowerCase().replace(/[^a-z]/g, '')}`}>
                      {skill.name}
                    </span>
                    <span className="text-slate-500 dark:text-slate-400">{skill.level}%</span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                    <div 
                      className="skill-bar bg-primary-600 h-2 rounded-full" 
                      style={{ width: '0%' }} 
                      data-width={skill.level}
                      data-testid={`skillbar-${skill.name.toLowerCase().replace(/[^a-z]/g, '')}`}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Frameworks & Tools */}
          <div ref={frameworksRef} className="animate-on-scroll">
            <h3 className="text-2xl font-semibold text-slate-900 dark:text-white mb-8">Frameworks & Tools</h3>
            <div className="space-y-6">
              {frameworkSkills.map((skill, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-2">
                    <span className="text-slate-700 dark:text-slate-300 font-medium" data-testid={`text-framework-${skill.name.toLowerCase().replace(/[^a-z]/g, '')}`}>
                      {skill.name}
                    </span>
                    <span className="text-slate-500 dark:text-slate-400">{skill.level}%</span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                    <div 
                      className="skill-bar bg-primary-600 h-2 rounded-full" 
                      style={{ width: '0%' }} 
                      data-width={skill.level}
                      data-testid={`frameworkbar-${skill.name.toLowerCase().replace(/[^a-z]/g, '')}`}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Technology Icons */}
        <div ref={techIconsRef} className="mt-16 animate-on-scroll">
          <h3 className="text-2xl font-semibold text-slate-900 dark:text-white text-center mb-8">Technologies I Work With</h3>
          <div className="flex flex-wrap justify-center items-center gap-8">
            <div className="bg-slate-100 dark:bg-slate-700 p-4 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors" data-testid="icon-python">
              <SiPython className="text-3xl text-blue-600" />
            </div>
            <div className="bg-slate-100 dark:bg-slate-700 p-4 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors" data-testid="icon-javascript">
              <SiJavascript className="text-3xl text-yellow-500" />
            </div>
            <div className="bg-slate-100 dark:bg-slate-700 p-4 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors" data-testid="icon-react">
              <SiReact className="text-3xl text-cyan-500" />
            </div>
            <div className="bg-slate-100 dark:bg-slate-700 p-4 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors" data-testid="icon-docker">
              <SiDocker className="text-3xl text-blue-500" />
            </div>
            <div className="bg-slate-100 dark:bg-slate-700 p-4 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors" data-testid="icon-aws">
              <SiAmazon className="text-3xl text-orange-500" />
            </div>
            <div className="bg-slate-100 dark:bg-slate-700 p-4 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors" data-testid="icon-git">
              <SiGit className="text-3xl text-red-500" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
