import { Download } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

export default function About() {
  const titleRef = useScrollAnimation();
  const imageRef = useScrollAnimation();
  const contentRef = useScrollAnimation();

  return (
    <section id="about" className="py-20 bg-white dark:bg-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={titleRef} className="text-center mb-16 animate-on-scroll">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">About Me</h2>
          <div className="w-24 h-1 bg-primary-600 mx-auto rounded-full"></div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div ref={imageRef} className="animate-on-scroll">
            <img 
              src="https://images.unsplash.com/photo-1571171637578-41bc2dd41cd2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Professional coding workspace" 
              className="rounded-xl shadow-lg w-full h-auto" 
            />
          </div>
          
          <div ref={contentRef} className="animate-on-scroll">
            <h3 className="text-2xl font-semibold text-slate-900 dark:text-white mb-6">Passionate Computer Science Student</h3>
            <p className="text-lg text-slate-600 dark:text-slate-300 mb-6">
              I'm currently pursuing my BS in Computer Science at the National University of Sciences & Technology, with an expected graduation in 2025. My journey in technology is driven by a deep passion for solving real-world problems through innovative solutions.
            </p>
            <p className="text-lg text-slate-600 dark:text-slate-300 mb-8">
              I specialize in web development, artificial intelligence, and mobile app development. I believe in continuous learning and applying cutting-edge technology to improve everyday life. My experience ranges from developing AI-powered applications to creating efficient web solutions.
            </p>
            
            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="text-center p-4 bg-slate-50 dark:bg-slate-700 rounded-lg">
                <div className="text-2xl font-bold text-primary-600 dark:text-primary-400" data-testid="text-projects-count">4+</div>
                <div className="text-sm text-slate-500 dark:text-slate-400">Projects Completed</div>
              </div>
              <div className="text-center p-4 bg-slate-50 dark:bg-slate-700 rounded-lg">
                <div className="text-2xl font-bold text-primary-600 dark:text-primary-400" data-testid="text-certifications-count">6+</div>
                <div className="text-sm text-slate-500 dark:text-slate-400">Certifications</div>
              </div>
            </div>
            
            {/* Download CV Button */}
            <div>
              <button 
                className="inline-flex items-center bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105"
                data-testid="button-download-cv"
              >
                <Download className="mr-2 h-4 w-4" />
                Download CV
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
