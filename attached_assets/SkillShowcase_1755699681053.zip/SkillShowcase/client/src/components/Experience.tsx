import { Calendar, Check, BarChart, Code, Brain, Network, FileText, Award } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

export default function Experience() {
  const titleRef = useScrollAnimation();
  const experienceRef = useScrollAnimation();
  const certificationsRef = useScrollAnimation();

  const certifications = [
    { icon: BarChart, title: "Google Data Analytics Certificate", issuer: "Coursera" },
    { icon: Code, title: "Python: Basic to Advanced", issuer: "FAST University" },
    { icon: Brain, title: "Prompt Engineering for AI Applications", issuer: "OpenAI" },
    { icon: Brain, title: "Artificial Intelligence Foundations", issuer: "LinkedIn Learning" },
    { icon: Network, title: "Deep Learning Specialization", issuer: "DeepLearning.AI" },
    { icon: FileText, title: "Responsive Web Development Bootcamp", issuer: "freeCodeCamp" },
  ];

  return (
    <section id="experience" className="py-20 bg-white dark:bg-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={titleRef} className="text-center mb-16 animate-on-scroll">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">Experience & Achievements</h2>
          <div className="w-24 h-1 bg-primary-600 mx-auto rounded-full"></div>
        </div>
        
        {/* Internship Experience */}
        <div className="mb-16">
          <h3 className="text-2xl font-semibold text-slate-900 dark:text-white mb-8 text-center">Professional Experience</h3>
          <div className="max-w-4xl mx-auto">
            <div ref={experienceRef} className="bg-slate-50 dark:bg-slate-700 rounded-xl p-8 animate-on-scroll">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                <div>
                  <h4 className="text-xl font-semibold text-slate-900 dark:text-white" data-testid="text-internship-title">AI & Web Development Intern</h4>
                  <p className="text-primary-600 dark:text-primary-400 font-medium" data-testid="text-internship-company">DATA-I, National Science and Technology Park (NSTP)</p>
                </div>
                <div className="text-slate-500 dark:text-slate-400 mt-2 md:mt-0 flex items-center">
                  <Calendar className="mr-1 h-4 w-4" />
                  <span data-testid="text-internship-duration">Jun 2025 – Aug 2025</span>
                </div>
              </div>
              <p className="text-slate-600 dark:text-slate-300 mb-4" data-testid="text-internship-location">Islamabad, Pakistan</p>
              <ul className="space-y-3 text-slate-600 dark:text-slate-300">
                <li className="flex items-start">
                  <Check className="text-primary-600 dark:text-primary-400 mr-3 mt-1 flex-shrink-0 h-4 w-4" />
                  <span data-testid="text-achievement-llm">Worked on Large Language Model (LLM) integration for various applications</span>
                </li>
                <li className="flex items-start">
                  <Check className="text-primary-600 dark:text-primary-400 mr-3 mt-1 flex-shrink-0 h-4 w-4" />
                  <span data-testid="text-achievement-chatbot">Developed and maintained an AI-powered chatbot for customer interaction</span>
                </li>
                <li className="flex items-start">
                  <Check className="text-primary-600 dark:text-primary-400 mr-3 mt-1 flex-shrink-0 h-4 w-4" />
                  <span data-testid="text-achievement-fullstack">Contributed to front-end development using HTML, CSS, JavaScript, and backend development</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
        
        {/* Certifications */}
        <div>
          <h3 className="text-2xl font-semibold text-slate-900 dark:text-white mb-8 text-center">Certifications & Achievements</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {certifications.map((cert, index) => (
              <div key={index} ref={certificationsRef} className="bg-slate-50 dark:bg-slate-700 rounded-lg p-6 text-center animate-on-scroll">
                <div className="w-16 h-16 bg-primary-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <cert.icon className="text-white h-8 w-8" />
                </div>
                <h4 className="font-semibold text-slate-900 dark:text-white mb-2" data-testid={`text-cert-title-${index + 1}`}>
                  {cert.title}
                </h4>
                <p className="text-sm text-slate-600 dark:text-slate-300" data-testid={`text-cert-issuer-${index + 1}`}>
                  {cert.issuer}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
