import { useScrollAnimation } from '../hooks/useScrollAnimation';

export default function Education() {
  const titleRef = useScrollAnimation();
  const bsRef = useScrollAnimation();
  const aLevelsRef = useScrollAnimation();
  const oLevelsRef = useScrollAnimation();

  return (
    <section className="py-20 bg-slate-50 dark:bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={titleRef} className="text-center mb-16 animate-on-scroll">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">Education</h2>
          <div className="w-24 h-1 bg-primary-600 mx-auto rounded-full"></div>
        </div>
        
        <div className="max-w-4xl mx-auto">
          {/* Education Timeline */}
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 h-full w-0.5 bg-primary-600"></div>
            
            {/* Education Items */}
            <div className="space-y-12">
              {/* BS Computer Science */}
              <div ref={bsRef} className="flex items-center animate-on-scroll">
                <div className="flex-shrink-0 w-8 h-8 bg-primary-600 rounded-full border-4 border-white dark:border-slate-900 relative z-10 md:absolute md:left-1/2 md:transform md:-translate-x-1/2"></div>
                <div className="ml-12 md:ml-0 md:w-1/2 md:pr-8 md:text-right">
                  <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg">
                    <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-2" data-testid="text-bs-title">BS in Computer Science</h3>
                    <p className="text-primary-600 dark:text-primary-400 font-medium mb-2" data-testid="text-bs-university">National University of Sciences & Technology</p>
                    <p className="text-slate-500 dark:text-slate-400 text-sm mb-3" data-testid="text-bs-duration">Expected 2025 | Islamabad, Pakistan</p>
                    <p className="text-slate-600 dark:text-slate-300">Specialized coursework in Machine Learning, Software Engineering, Cloud Computing, and Database Management Systems.</p>
                  </div>
                </div>
              </div>
              
              {/* A-Levels */}
              <div ref={aLevelsRef} className="flex items-center animate-on-scroll">
                <div className="flex-shrink-0 w-8 h-8 bg-primary-600 rounded-full border-4 border-white dark:border-slate-900 relative z-10 md:absolute md:left-1/2 md:transform md:-translate-x-1/2"></div>
                <div className="ml-12 md:ml-0 md:w-1/2 md:pl-8 md:ml-auto">
                  <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg">
                    <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-2" data-testid="text-alevels-title">Intermediate / A-Levels</h3>
                    <p className="text-slate-500 dark:text-slate-400 text-sm mb-3" data-testid="text-alevels-year">2021</p>
                    <p className="text-slate-600 dark:text-slate-300">Completed higher secondary education with focus on Mathematics and Science subjects.</p>
                  </div>
                </div>
              </div>
              
              {/* O-Levels */}
              <div ref={oLevelsRef} className="flex items-center animate-on-scroll">
                <div className="flex-shrink-0 w-8 h-8 bg-primary-600 rounded-full border-4 border-white dark:border-slate-900 relative z-10 md:absolute md:left-1/2 md:transform md:-translate-x-1/2"></div>
                <div className="ml-12 md:ml-0 md:w-1/2 md:pr-8 md:text-right">
                  <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg">
                    <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-2" data-testid="text-olevels-title">Matric / O-Levels</h3>
                    <p className="text-slate-500 dark:text-slate-400 text-sm mb-3" data-testid="text-olevels-year">2019</p>
                    <p className="text-slate-600 dark:text-slate-300">Foundation education with excellent performance in core subjects.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
