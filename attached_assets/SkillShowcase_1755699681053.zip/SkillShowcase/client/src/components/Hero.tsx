import { ArrowRight, Mail } from 'lucide-react';
import { SiLinkedin, SiGithub } from 'react-icons/si';

export default function Hero() {
  const scrollToProjects = () => {
    document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <div className="animate-fadeInUp">
            <img 
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" 
              alt="Muhammad Ibtesam" 
              className="w-32 h-32 rounded-full mx-auto mb-8 shadow-lg object-cover border-4 border-white dark:border-slate-700" 
            />
            
            <h1 className="text-4xl md:text-6xl font-bold text-slate-900 dark:text-white mb-6">
              Hi, I'm <span className="text-primary-600 dark:text-primary-400">Muhammad Ibtesam</span>
            </h1>
            <p className="text-xl md:text-2xl text-slate-600 dark:text-slate-300 mb-8 max-w-3xl mx-auto">
              Computer Science Student | Web Developer | AI Enthusiast
            </p>
            <p className="text-lg text-slate-500 dark:text-slate-400 mb-12 max-w-2xl mx-auto">
              Passionate about solving real-world problems through innovative, efficient, and impactful projects. Focused on web development, AI, and mobile app development.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <button 
                onClick={scrollToProjects}
                className="bg-primary-600 hover:bg-primary-700 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center"
                data-testid="button-view-work"
              >
                View My Work
                <ArrowRight className="ml-2 h-4 w-4" />
              </button>
              <button 
                onClick={scrollToContact}
                className="border-2 border-primary-600 text-primary-600 dark:text-primary-400 dark:border-primary-400 hover:bg-primary-600 hover:text-white dark:hover:bg-primary-400 dark:hover:text-slate-900 px-8 py-3 rounded-lg font-semibold transition-all duration-300"
                data-testid="button-get-in-touch"
              >
                Get In Touch
              </button>
            </div>
            
            {/* Social Links */}
            <div className="flex justify-center space-x-6 mt-12">
              <a 
                href="https://linkedin.com/in/muhammadibtesam" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-slate-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors text-2xl"
                data-testid="link-linkedin"
              >
                <SiLinkedin />
              </a>
              <a 
                href="https://github.com/ibtesamiqbal" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-slate-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors text-2xl"
                data-testid="link-github"
              >
                <SiGithub />
              </a>
              <a 
                href="mailto:muhammadibtesam51@gmail.com"
                className="text-slate-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors text-2xl"
                data-testid="link-email"
              >
                <Mail />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
