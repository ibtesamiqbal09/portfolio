import { Mail } from 'lucide-react';
import { SiLinkedin, SiGithub } from 'react-icons/si';

export default function Footer() {
  return (
    <footer className="bg-white dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="flex justify-center space-x-6 mb-8">
            <a 
              href="https://linkedin.com/in/muhammadibtesam" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-slate-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors text-2xl"
              data-testid="footer-link-linkedin"
            >
              <SiLinkedin />
            </a>
            <a 
              href="https://github.com/ibtesamiqbal" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-slate-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors text-2xl"
              data-testid="footer-link-github"
            >
              <SiGithub />
            </a>
            <a 
              href="mailto:muhammadibtesam51@gmail.com"
              className="text-slate-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors text-2xl"
              data-testid="footer-link-email"
            >
              <Mail />
            </a>
          </div>
          <p className="text-slate-600 dark:text-slate-400" data-testid="text-copyright">
            &copy; 2024 Muhammad Ibtesam. All rights reserved.
          </p>
          <p className="text-sm text-slate-500 dark:text-slate-500 mt-2" data-testid="text-tagline">
            Built with passion for technology and innovation
          </p>
        </div>
      </div>
    </footer>
  );
}
