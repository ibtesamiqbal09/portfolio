# Overview

This is a personal portfolio website for Muhammad Ibtesam, a Computer Science student. The application is a full-stack web application built with React on the frontend and Express.js on the backend, featuring a modern, responsive design with dark/light theme support. The portfolio showcases personal information, skills, projects, education, experience, and includes a functional contact form for visitor inquiries.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side is built with React and TypeScript, utilizing a component-based architecture:

- **UI Framework**: React with TypeScript for type safety and better developer experience
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Query (TanStack Query) for server state management and caching
- **Styling**: Tailwind CSS for utility-first styling with shadcn/ui components for consistent design system
- **Theme System**: Custom theme provider with light/dark mode support using CSS variables
- **Form Handling**: React Hook Form with Zod validation for type-safe form validation
- **Build Tool**: Vite for fast development and optimized production builds

The application follows a single-page application (SPA) pattern with smooth scrolling navigation between sections. Components are organized with clear separation of concerns, including custom hooks for scroll animations and responsive behavior.

### Backend Architecture
The server is built with Express.js using a RESTful API pattern:

- **Server Framework**: Express.js with TypeScript for type safety
- **API Structure**: RESTful endpoints for contact form submissions and data retrieval
- **Request Handling**: JSON middleware for parsing request bodies with comprehensive error handling
- **Development Setup**: Custom Vite integration for hot module replacement in development
- **Logging**: Custom request/response logging middleware for API monitoring

The backend uses a clean separation between routing logic and data storage, making it easy to extend with additional features.

### Data Storage Solutions
Currently implements an in-memory storage solution with plans for database integration:

- **Current Implementation**: MemStorage class using JavaScript Map for data persistence during runtime
- **Schema Definition**: Drizzle ORM schemas defined for future PostgreSQL integration
- **Database Preparation**: Drizzle configuration ready for PostgreSQL with Neon Database serverless driver
- **Data Models**: Contact form submissions with fields for name, email, subject, message, and timestamps

The storage interface is designed to be easily replaceable, allowing for seamless transition from memory storage to persistent database storage.

### External Dependencies

- **Database Service**: Configured for Neon Database (PostgreSQL-compatible serverless database)
- **Development Tools**: Replit integration with cartographer plugin and error overlay for development
- **UI Components**: Radix UI primitives for accessible, unstyled components
- **Styling**: Google Fonts integration (Inter, DM Sans, Fira Code, Geist Mono)
- **Icons**: Lucide React for general icons, React Icons for brand icons
- **Form Validation**: Zod for runtime type validation and schema definition
- **Date Handling**: date-fns for date manipulation and formatting
- **Animation**: Custom scroll-based animations with Intersection Observer API